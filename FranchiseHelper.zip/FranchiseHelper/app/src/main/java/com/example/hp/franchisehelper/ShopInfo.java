package com.example.hp.franchisehelper;

public class ShopInfo {

    String shopName;


    ShopInfo()
    {

    }
    ShopInfo(String shopName)
    {
        //this.shopId=shopId;
        this.shopName=shopName;
    }



    public String getShopName() {
        return shopName;
    }

}